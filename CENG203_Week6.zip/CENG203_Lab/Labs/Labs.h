#pragma once
// (Only the Week 6 prototype is shown here; keep your Week 2-5 prototypes above it)
void runWeek06();
