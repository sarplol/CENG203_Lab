#include "TreeUtils.h"
#include <iostream>
#include <queue>                    // std::queue: the library version of
using namespace std;                // Week 4's Queue, for any type

TreeNode* makeNode(int value)
{
    TreeNode* node = new TreeNode;
    node->data = value;
    node->left = nullptr;
    node->right = nullptr;
    return node;
}

// ============================ Q2 ============================
void preorder(const TreeNode* node)
{
    // TODO: base case; print; left; right
    if (node == nullptr)
        return;
    cout << node->data << " ";
    preorder(node->left);
    preorder(node->right);
}

void inorder(const TreeNode* node)
{
    // TODO: left; print; right
    if (node == nullptr)
        return;
    inorder(node->left);
    cout << node->data << " ";
    inorder(node->right);
}

void postorder(const TreeNode* node)
{
    // TODO: left; right; print
    if (node == nullptr)
        return;
    postorder(node->left);
    postorder(node->right);
    cout << node->data << " ";
}

int countNodes(const TreeNode* node)
{
    // TODO: 1 + left + right
    if (node == nullptr)
        return 0;
    return 1 + countNodes(node->left) + countNodes(node->right);
}

int countLeaves(const TreeNode* node)
{
    // TODO
    if (node == nullptr)
        return 0;
    if (node->left == nullptr && node->right == nullptr)
        return 1;                   // a leaf counts itself
    return countLeaves(node->left) + countLeaves(node->right);
}

// ============================ Q3 ============================
int height(const TreeNode* node)
{
    // TODO: 1 + the taller subtree
    if (node == nullptr)
        return -1;
    int hl = height(node->left);
    int hr = height(node->right);
    return 1 + (hl > hr ? hl : hr);
}

void levelOrder(const TreeNode* node)
{
    // TODO: std::queue<const TreeNode*>; push root; pop, print, push kids
    if (node == nullptr)
        return;
    queue<const TreeNode*> q;
    q.push(node);
    while (!q.empty()) {
        const TreeNode* cur = q.front();
        q.pop();
        cout << cur->data << " ";
        if (cur->left  != nullptr) q.push(cur->left);
        if (cur->right != nullptr) q.push(cur->right);
    }
}

// ============================ Q6 ============================
bool isBalanced(const TreeNode* node)
{
    // TODO: compare the heights, recurse
    if (node == nullptr)
        return true;
    int diff = height(node->left) - height(node->right);
    if (diff < -1 || diff > 1)
        return false;
    return isBalanced(node->left) && isBalanced(node->right);
}

// ============================ memory ============================
void destroy(TreeNode* node)
{
    if (node == nullptr)
        return;
    destroy(node->left);            // children first ...
    destroy(node->right);
    delete node;                    // ... the node last (postorder)
}
