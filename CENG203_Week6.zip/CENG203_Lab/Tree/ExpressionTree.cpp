#include "ExpressionTree.h"
#include <iostream>
#include <sstream>                  // stringstream: splits the tokens
#include <stack>                    // std::stack: Week 4's Stack, any type
#include <stdexcept>                // runtime_error
using namespace std;

bool isOperator(const string& token)
{
    return token == "+" || token == "-" || token == "*" || token == "/";
}

// ============================ Q8 ============================
ExprNode* buildFromPostfix(const string& postfix)
{
    stack<ExprNode*> st;            // holds finished subtrees
    stringstream ss(postfix);
    string token;
    while (ss >> token) {           // one token at a time: "3", "4", "+"
        // TODO: make a node; operator -> pop right, pop left; push it
        ExprNode* node = new ExprNode;
        node->data = token;
        node->left = nullptr;
        node->right = nullptr;
        if (isOperator(token)) {
            // first pop = right child, second pop = left child
            // (guard against malformed input such as "3 +")
            if (st.size() < 2) {
                delete node;
                while (!st.empty()) { destroyExpr(st.top()); st.pop(); }
                return nullptr;
            }
            node->right = st.top();  st.pop();
            node->left  = st.top();  st.pop();
        }
        st.push(node);
    }
    return st.empty() ? nullptr : st.top();
}

void printPrefix(const ExprNode* node)
{
    if (node == nullptr)
        return;
    cout << node->data << " ";      // operator first: Polish notation
    printPrefix(node->left);
    printPrefix(node->right);
}

void printPostfix(const ExprNode* node)
{
    if (node == nullptr)
        return;
    printPostfix(node->left);
    printPostfix(node->right);
    cout << node->data << " ";      // operator last: reverse Polish
}

// ============================ Q9 ============================
void printInfix(const ExprNode* node)
{
    // TODO: "(" left " op " right ")" for operators, the number otherwise
    if (node == nullptr)
        return;
    if (isOperator(node->data)) {
        cout << "(";
        printInfix(node->left);
        cout << " " << node->data << " ";
        printInfix(node->right);
        cout << ")";
    }
    else {
        cout << node->data;
    }
}

double evaluate(const ExprNode* node)
{
    // TODO: number -> stod; else combine
    if (node == nullptr)
        throw runtime_error("Empty expression");
    if (!isOperator(node->data))
        return stod(node->data);    // a number leaf

    double a = evaluate(node->left);    // children first (postorder)
    double b = evaluate(node->right);
    switch (node->data[0]) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        default:                    // '/'
            if (b == 0.0)
                throw runtime_error("Division by zero");
            return a / b;
    }
}

void destroyExpr(ExprNode* node)
{
    if (node == nullptr)
        return;
    destroyExpr(node->left);
    destroyExpr(node->right);
    delete node;
}
