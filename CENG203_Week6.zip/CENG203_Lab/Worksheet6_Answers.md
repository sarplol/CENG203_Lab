# CENG203 – Lab Worksheet #6 – Answers

Programming parts: see `Tree/*.cpp` (all `// TODO` comments are kept, the code is written under them). Output of menu option 6 matches every "Expected output" block.

---

## Q1 – Tree Vocabulary (5 pts)

**a)**

| Term | Your answer |
| --- | --- |
| root | 1 |
| leaves | 4, 5, 6 |
| internal nodes | 1, 2, 3 |
| parent of 5 / children of 3 | 2 / 6 |
| siblings of 4 | 5 |
| level of node 6 | 2 |
| depth of node 4 | 2 |
| height of node 2 | 1 |
| height of the tree | 2 |
| degree of node 3 / degree of the tree | 1 / 2 |
| number of edges | 5 |
| path from 1 to 6 | 1 – 3 – 6 |
| ancestors of 5 / descendants of 2 | 2, 1 / 4, 5 |

**b)**
- **Full: No.** Node 3 has exactly one child (6).
- **Perfect: No.** A perfect tree must be full, and this one is not (node 3 has only one child).
- **Complete: No.** Node 3 has a right child (6) but no left child, so the last level is not filled from the left.
- **Balanced: Yes.** At node 1 the subtree heights are 1 and 1; at node 3 they are −1 and 0 (difference 1); at nodes 2, 4, 5, 6 the difference is 0 or 0.
- **BST: No.** The left child 2 and its descendants 4, 5 are larger than the root 1, so "left < node" is violated.

**c)** Every node except the root has exactly one edge to its parent, and every edge belongs to exactly one child. So edges = (nodes without the root) = n − 1.

---

## Q2 – Three Traversals (10 pts)

**a)** Prediction (and actual output): preorder 1 2 4 5 3 6, inorder 4 2 5 1 3 6, postorder 4 5 2 6 3 1.

**b)** Frame of node 2:
- **Preorder:** the visit happens right when the frame starts. Nothing has returned yet; the calls for left (4) and right (5) are still to come.
- **Inorder:** the whole left subtree (node 4) has already returned; the right subtree (node 5) is still to come.
- **Postorder:** both children (4 and 5) have already returned; nothing but the return is left.

**c)** 4 frames: preorder(1) → preorder(2) → preorder(4) → preorder(nullptr). General formula: **h + 2** frames (h + 1 node frames along the longest path, plus one frame for the nullptr call). Here h = 2.

**d)** The nullptr test must come first because `node->left` on a null pointer crashes (access violation). The leaf test is checked after it because it needs a valid node. Without the leaf test every path ends in a nullptr call that returns 0, so the function would always return **0**. `destroy` uses **postorder**: children must be deleted before the node, otherwise after `delete node` we would lose the pointers to the children (memory leak / use after free).

**Try it:** moving the cout below the recursive calls gives **4 5 2 6 3 1**, which is the postorder output.

---

## Q3 – Height and Level Order (10 pts)

**a)** Returns: height(4) = 0, height(5) = 0, height(6) = 0, height(2) = 1, height(3) = 1, height(1) = 2. Every nullptr call below a leaf returns −1 (7 of them: two for each of 4, 5 and one for the missing left child of 3, two for 6 → 2+2+1+2 = 7). Total calls = 6 + 7 = **13** (= 2n + 1). A leaf gets 1 + max(−1, −1) = 0.

**b)** Only the base case changes: `return -1;` becomes `return 0;` for nullptr. The line then prints `height(root) = 3  height(node 4) = 1  height(empty) = 0`. `isBalanced` still works, because it uses only the **difference** of two heights, and both are shifted by the same 1.

**c)**

| Step | Popped and printed | Pushed | Queue after the step (front → back) |
| --- | --- | --- | --- |
| start | – | 1 | 1 |
| 1 | 1 | 2, 3 | 2 3 |
| 2 | 2 | 4, 5 | 3 4 5 |
| 3 | 3 | 6 | 4 5 6 |
| 4 | 4 | – | 5 6 |
| 5 | 5 | – | 6 |
| 6 | 6 | – | (empty) |

**d)** Preorder, inorder and postorder are depth-first; level order is breadth-first. Level order must process nodes in the order they were discovered (first in, first out) so a whole level is finished before the next one – that is a FIFO queue. The recursive traversals follow one path down and come back, which is last-in-first-out, and the call stack already does that. With a std::stack (right child pushed first, then left) the order becomes **preorder: 1 2 4 5 3 6**.

---

## Q4 – BST Insert (10 pts)

**a)**
```
          10
        /    \
       5      15
      / \    /  \
     3   7  12   20
```
insert(7): compare 7 with 10 → smaller, go left; compare with 5 → larger, go right; right child of 5 is nullptr → new node 7 becomes the right child of 5.

**b)** At every node: all keys of the left subtree are smaller, then the node, then all larger keys of the right subtree. Inorder prints exactly in that order, and by induction the left and right subtrees are printed in ascending order too – so it works for every BST. To rebuild the same shape save the **preorder**: the root comes first, then every parent is inserted before its children. Inorder would give the sorted sequence, and re-inserting sorted keys builds a chain.

**c)** For value == node->data neither branch runs, `inserted` stays false and the node is returned unchanged (duplicate ignored). With a plain `else`, an equal key goes to the right subtree: insert(10) returns **true**, inorder prints `3 5 7 10 10 12 15 20`, and **find / remove** become ambiguous – there are two nodes with key 10, and the BST rule "right > node" no longer holds strictly.

**d)** The function returns the root of the (sub)tree because the subtree may be a new node (when the old pointer was nullptr). The parent has to store the result: `node->left = insertInto(node->left, …)`. Without the assignment the new node would be created but never linked – it would be lost (memory leak) and the tree would not change. `inserted` is a `bool&` reference parameter, so the deepest call sets the variable that `insert()` owns.

**Try it:** inserting 3, 5, 7, 10, 12, 15, 20 gives a chain, height **6**.

---

## Q5 – Find, Min and Max (10 pts)

**a)**
- find(7): 10 (7 < 10 → left), 5 (7 > 5 → right), 7 (equal → found).
- find(8): 10 (8 < 10 → left), 5 (8 > 5 → right), 7 (8 > 7 → right) → nullptr → not found.

**b)** At most **h + 1** nodes. Q4 tree: h = 2 → 3 nodes. Chain of five keys: h = 4 → 5 nodes. Balanced tree with 1 000 000 keys: h ≈ log₂ 1 000 000 ≈ 19 → about **20** nodes. A linked list: **1 000 000** nodes in the worst case.

**c)** An empty tree has no minimum, and every int is a valid key, so `int findMin()` has no value to say "nothing there" (it would have to return a magic value or crash/throw). With `bool findMin(int&)` the bool reports success and the caller decides what to print.

**d)**
```cpp
// private static helper (needs one prototype in BST.h)
bool BST::findIn(const TreeNode* node, int value)
{
    if (node == nullptr)        return false;
    if (value == node->data)    return true;
    return value < node->data ? findIn(node->left, value)
                              : findIn(node->right, value);
}
bool BST::find(int value) const { return findIn(root, value); }
```
The recursive version uses more stack: up to h + 2 frames (O(h)), while the loop uses a constant amount (O(1)).

---

## Q6 – Shape and Balance (10 pts)

**a)**
```
1
 \
  2
   \
    3
     \
      4
       \
        5
```
Every new key is larger than all keys already in the tree, so it always goes right. It is a **singly linked list** (Week 3) in disguise. find(5) visits **5** nodes.

**b)** Difference = height(left) − height(right):
- Q4 tree: 10: 1 − 1 = 0; 5: 0 − 0 = 0; 15: 0; leaves 3, 7, 12, 20: (−1) − (−1) = 0. All are 0.
- Chain: node 1: −1 − 3 = −4; node 2: −1 − 2 = −3; node 3: −1 − 1 = −2; node 4: −1 − 0 = −1; node 5: 0.

The lowest node where |difference| ≤ 1 breaks is **node 3** (−2). `isBalanced` is an AND over all nodes (`… && isBalanced(left) && isBalanced(right)`), so one `false` is passed up to every ancestor and the root returns false (here the root already breaks the rule by itself with −4).

**c)** Search cost in a balanced tree with n = 1 000 000 is about 20 comparisons; in a chain it is up to 1 000 000. To get height 2 for 1, 2, 3, 4, 5 insert **3, 2, 4, 1, 5**. Rule: insert the **median** of the sorted range first, then recursively the median of the left half and of the right half (i.e. level by level of a perfect tree).

**d)** For a chain, `isBalanced(node k)` calls height on a subtree of size n − k, so the cost is n + (n−1) + … = **O(n²)**. One pass:
```cpp
// returns the height, or -2 if the subtree is not balanced
int checkHeight(const TreeNode* node)
{
    if (node == nullptr) return -1;
    int l = checkHeight(node->left);   if (l == -2) return -2;
    int r = checkHeight(node->right);  if (r == -2) return -2;
    if (l - r > 1 || r - l > 1) return -2;
    return 1 + (l > r ? l : r);
}
// isBalanced(root) == (checkHeight(root) != -2)      -> O(n)
```

---

## Q7 – Remove: Three Cases (10 pts)

**a)** Start: `10(5(3,7), 15(12,20))`
```
remove(3)  (leaf)          remove(5) (one child)      remove(10) (two children)
      10                         10                           12
     /  \                       /  \                         /  \
    5    15                    7    15                      7    15
     \   /  \                      /  \                          \
      7 12   20                   12   20                         20
```

**b)** The successor of 10 is **12**: go to the right child (15), then go left as far as possible. 12 is larger than everything in the left subtree (all ≤ 7) and smaller than everything else in the right subtree, so putting 12 in the root keeps "left < node < right". Yes, the **inorder predecessor** (largest key of the left subtree, 7) works symmetrically.

**c)** The successor is the leftmost node of the right subtree, so it has **no left child** – it is a leaf or has one child, and the recursive call ends in the simple cases. Therefore the cost of remove is **O(h)** (one walk down to the node and at most one more walk down to the successor).

**d)** remove(5) (after remove(3) the tree is `10(5(-,7), 15(12,20))`):
1. `removeFrom(10, 5)`: 5 < 10 → `node->left = removeFrom(5, 5)`.
2. `removeFrom(5, 5)`: equal → left is nullptr → **one-child case**: child = 7, node 5 is deleted, `removed = true`, returns 7 to the caller.
3. Back in `removeFrom(10, …)`: `left` becomes 7, the function returns node 10 to `BST::remove`, which stores it as root.

The function ends with `return node;` so every untouched node is handed back to its parent and the links stay the same. `return nullptr;` would cut the whole subtree off from its parent (and leak it).

**Try it:** final tree is `12(7, 15(-,20))`. remove(15): **one child** (20) → inorder `7 12 20`. Then remove(12) (root, two children): the successor is 20, the root key becomes 20 → inorder `7 20`.

---

## Q8 – Expression Tree from Postfix (10 pts)

**a)** The tokens are operators (`+`) and numbers that can have several digits or decimals (`42`, `3.5`). An int cannot store an operator, and a char cannot store `42`; a string stores both and `stod` converts the numbers when needed.

**b)** Postfix has no parentheses and no precedence rules: an operator always comes right after its two operands, so one left-to-right pass with a stack is enough. For infix the builder must handle operator precedence, associativity and parentheses (for example with the shunting-yard algorithm or a recursive-descent parser).

**c)** The stack is LIFO: the top is the most recently pushed node, and the right operand is read last. For `5 2 -` the stack is [5, 2]; the first pop gives 2 = right child, the second gives 5 = left child → 5 − 2 = 3. Popping the other way round gives left = 2, right = 5 → 2 − 5 = −3 (wrong).

**d)**

| Token | Action | Stack after the token (bottom → top) |
| --- | --- | --- |
| 3 | make leaf, push | 3 |
| 4 | make leaf, push | 3, 4 |
| + | pop 4 (right), pop 3 (left), push new node | (3 + 4) |
| 5 | make leaf, push | (3 + 4), 5 |
| 2 | make leaf, push | (3 + 4), 5, 2 |
| - | pop 2 (right), pop 5 (left), push new node | (3 + 4), (5 - 2) |
| * | pop (5 - 2) (right), pop (3 + 4) (left), push new node | ((3 + 4) * (5 - 2)) |

**e)** Preorder visits the node before its children, so the operator is printed before its operands = prefix. Postorder visits it after its children, so the operator is printed after its operands = postfix. `printPrefix` / `printPostfix` have the same structure as `preorder` / `postorder` of Q2: base case nullptr, then the print line and the two recursive calls in a different order – only the printed type (string) differs.

---

## Q9 – Infix with Parentheses and Evaluation (10 pts)

**a)** The tree stores the grouping in its **shape**, but a plain inorder print only writes the tokens. For (3 + 4) * 5 the tree is `*` with left child `+(3,4)` and right child 5; a plain inorder print gives `3 + 4 * 5`. A reader applies the usual precedence and computes 3 + 20 = **23**, but the tree means (3 + 4) * 5 = **35**. The parentheses restore the grouping.

**b)** `evaluate` is **postorder**: both children are evaluated first, then the node combines their values. Prefix, infix and postfix are only different ways of **writing** the same tree; the tree (built from any of them) is identical, so one `evaluate` serves all. There is no "preorder evaluation" because an operator cannot be applied before its operands have values.

**c)** Returning 0 would be a wrong value that looks like a real result, and printing inside `evaluate` mixes output into the logic while the caller carries on with garbage. A thrown exception forces the caller to deal with the error. When it is thrown inside the `/` node the frames between it and the `catch` (the evaluate frames of the `/` node and whatever is above it) are **unwound** (their local variables are destroyed and they end immediately) until the `try` block in `runWeek06` handles it. `double value = evaluate(bad);` never finishes, so the next line (`[Q9] value = …`) is skipped.

**d)** `"3 +"`: the `+` needs two operands but only one node is on the stack – the second pop would be on an empty stack (undefined behaviour / crash). Check: `st.size() >= 2` before popping the operands (done in the code). `"3 4"`: no operator at all; the stack ends with two nodes, the function returns the top (4) and silently ignores 3 (and leaks it). Check: after the loop, the stack must contain **exactly one** node, otherwise the input is invalid.

**Try it:** `3 4 5 * +` → `(3 + (4 * 5))` = 23. `3 4 + 5 *` → `((3 + 4) * 5)` = 35.

---

## Q10 – Putting It Together (15 pts)

**a)** Method (preorder 1 2 4 5 3 6, inorder 4 2 5 1 3 6):
1. The first element of the preorder is the root: **1**.
2. Find 1 in the inorder: the keys to its left (4 2 5) form the left subtree, the keys to its right (3 6) the right subtree.
3. The left subtree has 3 nodes, so the next 3 elements of the preorder (2 4 5) are its preorder. Repeat: root 2; in inorder 4 is to its left and 5 to its right → left child 4, right child 5.
4. The right subtree's preorder is 3 6, inorder 3 6: root 3, nothing left of it, 6 to its right → right child 6.

The result is the tree of Q1/Q2. **Preorder and postorder alone do not** determine a tree uniquely: for a root A with one child B, preorder = A B and postorder = B A for both "B is the left child" and "B is the right child". (They are unique only if every node has 0 or 2 children.)

**b)**

| | Binary tree (BT) | Binary search tree (BST) |
| --- | --- | --- |
| Rule for the keys | At most two children per node; no rule for the keys | left subtree < node < right subtree, at every node |
| Inorder traversal prints | Some order that depends on the shape | The keys in ascending order |
| Searching a key | Has to look at all nodes: O(n) | Walks down one path: O(h) |
| Shape is decided by | Whoever builds it (free) | The insertion order of the keys |
| Example this week | The tree 1…6 of Q2, the expression tree | The tree built from 10, 5, 15, 7, 12, 20, 3 |

**c)**

| Tree | Full? | Perfect? | Complete? | Balanced? | Height |
| --- | --- | --- | --- | --- | --- |
| T1 | Yes | Yes | Yes | Yes | 2 |
| T2 | No (node 3 has one child) | No | No (node 3 has no left child but a right child) | Yes | 2 |
| T3 | No | No | No | No | 4 |
| T4 | No (node 3 has one child) | No | Yes (last level 4, 5, 6 is filled from the left) | Yes | 2 |

**d)**
1. **Print the folder tree with indentation:** **preorder** – a folder is printed before its contents, and the depth of the recursion gives the indentation.
2. **Size of every folder:** **postorder** – the sizes of all children have to be known before the folder's own size can be computed.
3. **Keys of a BST in ascending order:** **inorder** – left (smaller), node, right (larger).
4. **Node closest to the root that satisfies a condition:** **level order** (breadth-first) – it visits the nodes level by level, so the first match is the closest to the root.

**e)** Commit message: `Week 6 - trees`. Repository URL: https://github.com/rushout912/CENG203_Lab
